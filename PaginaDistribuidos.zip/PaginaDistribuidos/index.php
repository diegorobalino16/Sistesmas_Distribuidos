<?php
$GLOBALS['THRIFT_ROOT'] = 'C:\\Users\\RichardVivanco\\Downloads\\thrift-0.11.0\\thrift-0.11.0\\lib\\php\\lib\\';

require_once 'Types.php';
require_once 'Servidor.php';

require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Transport/TTransport.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Transport/TSocket.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Protocol/TProtocol.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Protocol/TBinaryProtocol.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Transport/TBufferedTransport.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Type/TMessageType.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Factory/TStringFuncFactory.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/StringFunc/TStringFunc.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/StringFunc/Core.php';
require_once $GLOBALS['THRIFT_ROOT'].'/Thrift/Type/TType.php';
use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TSocket;
use Thrift\Transport\TSocketPool;
use Thrift\Transport\TFramedTransport;
use Thrift\Transport\TBufferedTransport;

$host = '127.0.0.1';
$port = 7911;
$socket = new Thrift\Transport\TSocket($host,$port);
$transport = new TBufferedTransport($socket);
$protocol = new TBinaryProtocol($transport);

$client = new ServidorClient($protocol);
$transport->open();
?>




<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Gif 10</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500" rel="stylesheet">
		<!--
		CSS
		============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/nice-select.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/main.css">
	</head>
	<body>
	<div class="oz-body-wrap">
		<!-- Start Header Area -->
		<header class="default-header">
			<div class="container-fluid">
				<div class="header-wrap">
					<div class="header-top d-flex justify-content-between align-items-center">
						<div class="logo">
							
						</div>
						<div class="main-menubar d-flex align-items-center">
							<nav class="hide">
								<a href="index.html">Inicio</a>
								<a href="integrantes.html">Integrantes</a>
							</nav>
							<div class="menu-bar"><span class="lnr lnr-menu"></span></div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header Area -->
		<!-- Start Banner Area -->
		<section class="banner-area relative">
			<div class="container">
				<div class="row fullscreen align-items-center justify-content-center">
					<div class="banner-left col-lg-6">
						<img class="d-flex mx-auto img-fluid" src="img/espol.png" alt="">
					</div>
					<div class="col-lg-6">
						<div class="story-content">
							<h1>Proyecto de <span class="sp-1">Sistemas</span><br>
							<span class="sp-2">Distribuidos</span></h1>
                            
                            <!-------------------------------------PHP------------------------------->
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
                              <button type="submit" class="genric-btn primary circle arrow">Obtener top10 de Gifts<span class="lnr lnr-arrow-right"></span></button>
                            </form>
                            <!--------------------------------------PHP---------------------------->
				    	</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Banner Area -->
		
		<!-- Start about Area -->
		<section class="about-area pt-100 pb-100">
			<div class="container">
				                
                <!------------------------------------PHP----------------------------------------->
                 <?php
    $dato1  =$resultado= "";
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $re = $client->top10("hola");
      $resultado = "".$re;
    }
   ?>

<br>
<span class="error">
<?php

$valor_array = explode(';',$resultado);
   ?>

<div class="container">
<table class="table table-striped">
    <thead>
      <tr>
        <th>Id</th>
        <th>Visitas</th>
        <th>Titulo</th>
        <th>Editor</th>
      </tr>
    </thead>
    <tbody>
<?php
foreach($valor_array as $llave => $valores) {

    $noticias =explode(',',$valores);
 ?>
    <tr>
    <td> <?php if (isset($noticias[0])) {echo $noticias[0]; }  ?> </td>
    <td> <?php if (isset($noticias[1])) {echo $noticias[1]; }  ?> </td>
    <td> <?php if (isset($noticias[2])) {echo $noticias[2]; }  ?> </td>
    <td> <?php if (isset($noticias[3])) {echo $noticias[3]; }  ?> </td>
    </tr>
    <?php
}
?>
</tbody>
  </table>
  </div>
</span>
                
                <!------------------------------------PHP----------------------------------------->
                
                
			</div>
		</section>
		<!-- End Team Force Area -->
		
        
        
        
		<!-- Strat Footer Area -->
		<footer class="section-gap">
			<div class="container">
				
				<div class="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
					<p class="footer-text m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> todos los derechos reservados | Proyecto de Sistemas Distribuidos.</p>
                </div>
			</div>
		</footer>
		<!-- End Footer Area -->
	</div>

		<script src="js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="js/vendor/bootstrap.min.js"></script>
		<script src="js/jquery.ajaxchimp.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/jquery.counterup.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>
